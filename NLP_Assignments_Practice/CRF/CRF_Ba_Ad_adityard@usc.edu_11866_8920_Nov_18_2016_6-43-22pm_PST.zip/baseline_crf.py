from DialogueAnalyzer import *
import sys

#train : /home/aditya/CSCI544Corpus/discourse/train
#dev : /home/aditya/CSCI544Corpus/discourse/dev
#Output : 



if __name__ == "__main__":
    print("Beginning")
    dialogueAnalyzerObj = DialogueAnalyzer()
    dialogueAnalyzerObj.analyzeUtteranceBasic(sys.argv[1],True) #INPUTDIR
    dialogueAnalyzerObj.trainCRFBasic('swbdBasic.crfsuite')
    dialogueAnalyzerObj.predictfromCRFBasic(sys.argv[2]) #TESTDIR
    dialogueAnalyzerObj.writePredictionsBasic(sys.argv[3]) #OUTFILE